using Vaichuve.Native.ViewModels;

namespace Vaichuve.Pages;

public partial class HistoricoPage : ContentPage
{
	public HistoricoPage(ClimaViewModel climaViewModel)
	{
		InitializeComponent();
		BindingContext = climaViewModel;
	}
}