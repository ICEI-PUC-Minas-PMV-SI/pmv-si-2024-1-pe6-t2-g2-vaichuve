using Vaichuve.Native.ViewModels;

namespace Vaichuve.Pages;

public partial class PrevisaoPage : ContentPage
{
	public PrevisaoPage(ClimaViewModel climaViewModel)
	{
		InitializeComponent();
		BindingContext = climaViewModel;
	}
}