using Vaichuve.Application.DataModels;
using Vaichuve.Native.Services;
using Vaichuve.Native.ViewModels;
using Vaichuve.Pages;

namespace Vaichuve.Native.Pages;

public partial class LocaisPage : ContentPage
{
    LocaisViewModel _locaisViewModel { get; set; }
    LocationService _locationService;

    public LocaisPage(LocaisViewModel locaisViewModel, LocationService locationService)
    {
        InitializeComponent();
        _locaisViewModel = locaisViewModel;
        BindingContext = locaisViewModel;
        _locationService = locationService;
    }

    protected async override void OnAppearing()
    {
        base.OnAppearing();
        await _locaisViewModel.PegarEstados();
    }

    public async void EscolheEstado(object sender, SelectionChangedEventArgs e)
    {
        EstadoModel estadoEscolhido = e.CurrentSelection?.FirstOrDefault() as EstadoModel;

        if (estadoEscolhido != null)
        {
            await _locaisViewModel.EscolheEstado(estadoEscolhido);
        }
    }

    private async void CollectionView_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        CidadeModel cidadeEscolhida = e.CurrentSelection?.FirstOrDefault() as CidadeModel;

        if (cidadeEscolhida != null)
        {
            _locationService.ManualSetLocation(cidadeEscolhida.lat, cidadeEscolhida.lon);
            _locationService.EscolhiNovaCidade = true;
            await Shell.Current.GoToAsync("//HomePage");
        }
    }
}