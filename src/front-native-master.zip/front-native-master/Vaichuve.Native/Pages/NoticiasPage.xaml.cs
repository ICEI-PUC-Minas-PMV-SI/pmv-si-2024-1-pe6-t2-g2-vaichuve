namespace Vaichuve.Pages;

public partial class NoticiasPage : ContentPage
{
	public NoticiasPage()
	{
		InitializeComponent();
	}
}