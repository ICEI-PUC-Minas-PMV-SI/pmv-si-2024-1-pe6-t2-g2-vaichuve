using Vaichuve.Application.DataModels;
using Vaichuve.Native.Services;
using Vaichuve.Native.ViewModels;

namespace Vaichuve.Pages;

public partial class HomePage : ContentPage
{
	ClimaViewModel _ViewModel;
	LocationService _LocationService;

	public HomePage(ClimaViewModel viewModel, LocationService locationService)
	{
		InitializeComponent();
		_LocationService = locationService;
		_ViewModel = viewModel;
		BindingContext = viewModel;
	}

    protected async override void OnAppearing()
    {
        base.OnAppearing();

		if (_ViewModel.Lat == null | _ViewModel.Lon == null)
		{
			await _ViewModel.SetLocation();
			await _ViewModel.BuscaClimaDoDiaParaLocalLatLonCommand.ExecuteAsync(this);
			await _ViewModel.BuscarPrevisoesClimasCommand.ExecuteAsync(this);
			_ViewModel.DataLabelInfo = _ViewModel.ClimaDisplayed.RetornaData();			
			_ViewModel.LocalLabelInfo = _ViewModel.ClimaDisplayed._CidadeAtual + ", " + _ViewModel.ClimaDisplayed._EstadoAtual;
			_ViewModel.BuscarCidadesFavoritasCommand.Execute(this);
		}
    }

    protected async override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        base.OnNavigatedTo(args);

		if (_LocationService.EscolhiNovaCidade)
		{
            _LocationService.EscolhiNovaCidade = false;
			await _ViewModel.BuscaClimaDoDiaParaLocalLatLonCommand.ExecuteAsync(this);
            _ViewModel.DataLabelInfo = _ViewModel.ClimaDisplayed.RetornaData();
            _ViewModel.LocalLabelInfo = _ViewModel.ClimaDisplayed._CidadeAtual + ", " + _ViewModel.ClimaDisplayed._EstadoAtual;
            _ViewModel.BuscarCidadesFavoritasCommand.Execute(this);
        }
    }

    private async void EscolhidoCidadeFavorita(object sender, SelectionChangedEventArgs e)
    {
		CidadeModel c = e.CurrentSelection.FirstOrDefault() as CidadeModel;
		_LocationService.ManualSetLocation(c.lat, c.lon);
		await _ViewModel.BuscaClimaDoDiaParaLocalLatLonCommand.ExecuteAsync(this);
        _ViewModel.DataLabelInfo = _ViewModel.ClimaDisplayed.RetornaData();
        _ViewModel.LocalLabelInfo = _ViewModel.ClimaDisplayed._CidadeAtual + ", " + _ViewModel.ClimaDisplayed._EstadoAtual;
    }
}