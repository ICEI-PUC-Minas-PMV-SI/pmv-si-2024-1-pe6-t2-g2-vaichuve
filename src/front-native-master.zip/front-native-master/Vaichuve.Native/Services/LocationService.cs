﻿using System.Collections.Generic;
using System.Text.Json;
using Vaichuve.Application.DataModels;
using Vaichuve.Data.Entities;

namespace Vaichuve.Native.Services
{
    public class LocationService
    {
        // Valores padrões correspondem a Brasília.
        public double _Latitude { get; private set; } = -15.826691;
        public double _Longitude { get; private set; } = -47.921822;

        readonly string LocaisFavoritosFileName = Path.Combine(FileSystem.AppDataDirectory, "locaisFav");

        public bool EscolhiNovaCidade { get; set; } = false;

        public async Task<int> TryGetDeviceLocation()
        {
            Location? location = await Geolocation.Default.GetLastKnownLocationAsync();

            if (location != null)
            {
                _Latitude = location.Latitude;
                _Longitude = location.Longitude;
                return 1;
            }

            return 0;
        }

        public void ManualSetLocation(double latitude, double longitude)
        {
            _Latitude = latitude;
            _Longitude = longitude;
        }

        public void SalvarLocalFavorito(CidadeModel cidade)
        {
            if (!File.Exists(LocaisFavoritosFileName))
            {
                List<CidadeModel> CidadesFavoritos = new()
                {
                    cidade
                };  
                File.WriteAllText(LocaisFavoritosFileName, JsonSerializer.Serialize(CidadesFavoritos));
            } else
            {
                List<CidadeModel> CidadesFavoritos = RetornaListaDeLocaisFavoritos();

                if(!CidadesFavoritos.Contains(cidade))
                {
                    CidadesFavoritos.Add(cidade);
                    File.WriteAllText(LocaisFavoritosFileName, JsonSerializer.Serialize(CidadesFavoritos));
                }
            }
        }

        public List<CidadeModel> RetornaListaDeLocaisFavoritos()
        {
            if (!File.Exists(LocaisFavoritosFileName)) return new List<CidadeModel>();

            string ListaFavoritosJson = File.ReadAllText(LocaisFavoritosFileName);

            List<CidadeModel> ListaFavoritos = JsonSerializer.Deserialize<List<CidadeModel>>(ListaFavoritosJson);

            if(ListaFavoritos == null) return new List<CidadeModel>();

            return ListaFavoritos;
        }

        public void RemoverCidadeFavoritada(string nomeCidade)
        {
            List<CidadeModel> CidadesFavoritos = RetornaListaDeLocaisFavoritos();
            List<CidadeModel> NovaListaDeCidades = new List<CidadeModel>();

            foreach (CidadeModel c in CidadesFavoritos)
            {
                if (c.nome != nomeCidade)
                {
                    NovaListaDeCidades.Add(c);
                }                
            }

            File.WriteAllText(LocaisFavoritosFileName, JsonSerializer.Serialize(NovaListaDeCidades));
        }
    }
}
