﻿using Vaichuve.Native.Pages;
using Vaichuve.Pages;

namespace Vaichuve.Native
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();

            Routing.RegisterRoute(nameof(HomePage), typeof(HomePage));
            Routing.RegisterRoute(nameof(LocaisPage), typeof(LocaisPage));
            Routing.RegisterRoute(nameof(NoticiasPage), typeof(NoticiasPage));
            Routing.RegisterRoute(nameof(PrevisaoPage), typeof(PrevisaoPage));
            Routing.RegisterRoute(nameof(SettingsPage), typeof(SettingsPage));
            Routing.RegisterRoute(nameof(HistoricoPage), typeof(HistoricoPage));
        }
    }
}
