﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Vaichuve.Application.DataModels;
using Vaichuve.Application.Services;
using Vaichuve.Application.Ultility;
using Vaichuve.Native.Services;

namespace Vaichuve.Native.ViewModels
{
    public partial class ClimaViewModel : ObservableObject
    {
        DataService _dataService;
        LocationService _locationService;
        public ClimaViewModel(DataService dataService, LocationService locationService)
        {
            _dataService = dataService;
            _locationService = locationService;
        }

        public double? Lat;
        public double? Lon;
        public bool IsNotLoading => !IsLoading;
        public bool LocalAtualFavoritado => ChecarSeLocalAtualEstaFavoritado();
        public bool LocalAtualNotFavoritado => !ChecarSeLocalAtualEstaFavoritado();

        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(LocalAtualFavoritado))]
        [NotifyPropertyChangedFor(nameof(LocalAtualNotFavoritado))]
        ClimaDiarioModel? climaDisplayed;

        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(IsNotLoading))]
        bool isLoading;

        [ObservableProperty]
        string? dataLabelInfo;

        [ObservableProperty]
        string? localLabelInfo;

        [ObservableProperty]
        bool temLocaisFavoritos;

        public ObservableCollection<CidadeModel> cidadeFavoritas { get; } = new ObservableCollection<CidadeModel>();

        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(LocalAtualFavoritado))]
        [NotifyPropertyChangedFor(nameof(LocalAtualNotFavoritado))]
        int updates = 0;

        public ObservableCollection<ClimaDiarioModel> HistoricoClimas { get; } = new();
        public ObservableCollection<ClimaDiarioModel> PrevisaoClimas { get; } = new();


        bool ChecarSeLocalAtualEstaFavoritado()
        {
            if (ClimaDisplayed != null)
            {
                foreach (CidadeModel c in cidadeFavoritas)
                {
                    if (c.nome == ClimaDisplayed._CidadeAtual)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public async Task SetLocation()
        {
            await _locationService.TryGetDeviceLocation();
            Lat = _locationService._Latitude;
            Lon = _locationService._Longitude;
        }

        public void SetLocation(double lat, double lon)
        {
            _locationService.ManualSetLocation(lat, lon);
            Lat = _locationService._Latitude;
            Lon = _locationService._Longitude;
        }

        [RelayCommand]
        async Task BuscaClimaDoDiaParaLocalLatLon()
        {
            try
            {
                IsLoading = true;
                ClimaDisplayed = await _dataService.retornaClimaDoDia(_locationService._Latitude, _locationService._Longitude);
                List<ClimaDiarioModel> retorno = await _dataService.RetornaHistoricoDeClimas(_locationService._Latitude, _locationService._Longitude);

                retorno = retorno.OrderByDescending(x => x._DataAtual).Skip(1).ToList();

                foreach (ClimaDiarioModel c in retorno)
                {
                    HistoricoClimas.Add(c);
                }
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Erro!", ex.Message, "Continuar!");
            }
            finally
            {
                if (ClimaDisplayed != null)
                {
                    DataLabelInfo = ClimaDisplayed.RetornaData();
                    LocalLabelInfo = ClimaDisplayed._CidadeAtual + ", " + ClimaDisplayed._EstadoAtual;
                }
                else
                {
                    DataLabelInfo = "erro";
                    LocalLabelInfo = "erro";
                }
                IsLoading = false;
            }
        }

        [RelayCommand]
        void SalvarLocalFavorito()
        {
            IsLoading = true;

            CidadeModel cidade = new CidadeModel()
            {
                EstadoId = Conversores.GetEstadoIdBySigla(ClimaDisplayed._EstadoAtual),
                Id = 0,
                lat = _locationService._Latitude,
                lon = _locationService._Longitude,
                nome = ClimaDisplayed._CidadeAtual,
                nomeEstado = ClimaDisplayed._EstadoAtual
            };

            _locationService.SalvarLocalFavorito(cidade);
            List<CidadeModel> c = _locationService.RetornaListaDeLocaisFavoritos();

            cidadeFavoritas.Clear();

            foreach (CidadeModel cid in c)
            {
                cidadeFavoritas.Add(cid);
            }

            Updates++;

            IsLoading = false;
        }

        [RelayCommand]
        void BuscarCidadesFavoritas()
        {
            IsLoading = true;

            List<CidadeModel> c = _locationService.RetornaListaDeLocaisFavoritos();

            cidadeFavoritas.Clear();

            foreach (CidadeModel cid in c)
            {
                cidadeFavoritas.Add(cid);
            }

            Updates++;

            if (cidadeFavoritas.Any()) { TemLocaisFavoritos = true;  } else { TemLocaisFavoritos = false; }

            IsLoading = false;
        }

        [RelayCommand]
        void RemoverCidadeFavorita()
        {
            IsLoading = true;

            _locationService.RemoverCidadeFavoritada(ClimaDisplayed._CidadeAtual);

            BuscarCidadesFavoritas();

            Updates++;

            IsLoading = false;
        }

        [RelayCommand]
        async Task VoltarAoLocalAtual()
        {
            IsLoading = true;
            await _locationService.TryGetDeviceLocation();
            await BuscaClimaDoDiaParaLocalLatLon();
            Updates++;
            IsLoading = false;
        }

        [RelayCommand]
        async Task BuscarPrevisoesClimas()
        {
            IsLoading = true;
            List<ClimaDiarioModel> retorno = await _dataService.RetornaPrevisoesDeClima(_locationService._Latitude, _locationService._Longitude);

            foreach (ClimaDiarioModel d in retorno)
            {
                PrevisaoClimas.Add(d);
            }

            IsLoading = false;
        }
    }
}
