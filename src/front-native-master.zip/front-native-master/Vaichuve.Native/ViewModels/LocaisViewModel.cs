﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using Vaichuve.Application.DataModels;
using Vaichuve.Application.Services;
using Vaichuve.Native.Services;

namespace Vaichuve.Native.ViewModels
{
    public partial class LocaisViewModel : ObservableObject
    {
        DataService _dataService;

        public LocaisViewModel(DataService dataService)
        {
            _dataService = dataService;
        }

        [ObservableProperty]
        int update;

        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(isNotLoading))]
        bool isLoading;

        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(ufFoiAindaNaoFoiEscolhido))]
        bool ufFoiEscolhido;  
        
        public bool ufFoiAindaNaoFoiEscolhido => !UfFoiEscolhido;
        public bool isNotLoading => !IsLoading;


        public ObservableCollection<EstadoModel> ListaEstados { get; } = new ObservableCollection<EstadoModel>();
        public ObservableCollection<CidadeModel> ListaCidadesDoEstadoEscolhido { get; } = new ObservableCollection<CidadeModel>();

        public async Task PegarEstados()
        {
            IsLoading = true;

            List<EstadoModel> r = await _dataService.RetornaTodosEstados();

            foreach (EstadoModel estado in r)
            {
                if (estado.Name != "Exterior")
                {
                    ListaEstados.Add(estado);
                }
            }

            Update++;
            IsLoading = false;
        }

        public async Task EscolheEstado(EstadoModel estado)
        {
            IsLoading = true;
            UfFoiEscolhido = true;

            ListaCidadesDoEstadoEscolhido.Clear();

            List<CidadeModel> retorno = await _dataService.RetornaTodasCidadesDoEstado(estado.Id);

            foreach (CidadeModel c in  retorno)
            {
                ListaCidadesDoEstadoEscolhido.Add(c);
            }

            Update++;
            IsLoading = false;
        }

        [RelayCommand]
        void Voltar()
        {
            ListaCidadesDoEstadoEscolhido.Clear();
            UfFoiEscolhido = false;
            Update++;
        }
    }
}
