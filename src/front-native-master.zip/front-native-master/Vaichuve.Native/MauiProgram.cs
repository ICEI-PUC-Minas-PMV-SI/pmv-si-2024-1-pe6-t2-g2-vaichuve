﻿using Supabase;
using CommunityToolkit.Maui;
using Vaichuve.Data.Services;
using Vaichuve.Application.Services;
using Vaichuve.Native.Services;
using Vaichuve.Native.ViewModels;
using Vaichuve.Pages;
using Vaichuve.Native.Pages;
using Microsoft.Extensions.Logging;

namespace Vaichuve.Native
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .UseMauiCommunityToolkit()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                    fonts.AddFont("HelveticaNeueBold.otf", "HelveticaNeueBold");
                    fonts.AddFont("HelveticaNeueHeavy.otf", "HelveticaNeueHeavy");
                    fonts.AddFont("HelveticaNeueItalic.ttf", "HelveticaNeueItalic");
                    fonts.AddFont("HelveticaNeueLight.otf", "HelveticaNeueLight");
                    fonts.AddFont("HelveticaNeueMedium.otf", "HelveticaNeueMedium");
                });

            string url = "https://srejuickxwniocpkimuf.supabase.co";
            string key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNyZWp1aWNreHduaW9jcGtpbXVmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTA5NzYzMTYsImV4cCI6MjAyNjU1MjMxNn0.3kqbjnPCe1_Gq1_gGW5gvbc4PMKX-EDdg4jcO0zSB9s";
            
            SupabaseOptions supabaseOptions = new SupabaseOptions()
            {
                AutoRefreshToken = true,
                AutoConnectRealtime = true,
            };

            builder.Services.AddSingleton<ClimaViewModel>();
            builder.Services.AddTransient<LocaisViewModel>();
            builder.Services.AddSingleton<HomePage>();
            builder.Services.AddSingleton<HistoricoPage>();
            builder.Services.AddSingleton<PrevisaoPage>();
            builder.Services.AddTransient<LocaisPage>();
            builder.Services.AddSingleton<LocationService>();
            builder.Services.AddSingleton(provider => new Client(url, key, supabaseOptions));
            builder.Services.AddSingleton<WttrService>();
            builder.Services.AddSingleton<SupabaseDatabaseService>();
            builder.Services.AddSingleton<DataService>();

#if DEBUG
            builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}
