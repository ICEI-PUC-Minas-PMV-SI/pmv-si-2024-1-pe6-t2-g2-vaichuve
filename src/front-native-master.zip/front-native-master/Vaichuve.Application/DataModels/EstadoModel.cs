﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vaichuve.Application.DataModels
{
    public class EstadoModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Uf { get; set; }
    }
}
