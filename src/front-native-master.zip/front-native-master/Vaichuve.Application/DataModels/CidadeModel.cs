﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vaichuve.Application.Ultility;

namespace Vaichuve.Application.DataModels
{
    public class CidadeModel
    {
        public int EstadoId { get; set; }
        public int Id { get; set; }
        public string? nome { get; set; }
        public string? nomeEstado { get; set; }
        public double lat { get; set; }
        public double lon { get; set; }
      
    }
}
