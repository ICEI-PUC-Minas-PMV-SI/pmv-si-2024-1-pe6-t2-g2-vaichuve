﻿namespace Vaichuve.Application.DataModels
{
    public class ClimaModel
    {
        public int _TemperaturaEmC { get; set; } = 0;
        public string _Descricao { get; set; } = string.Empty;
        public int _HumidadeDoAr { get; set; } = 0;

        public string RetornaClima()
        {
            return _TemperaturaEmC.ToString() + "°C,";
        }
        public string RetornaClimaComDescricao()
        {
            return _TemperaturaEmC.ToString() + "°C," + " o clima está " + _Descricao;
        }
    }
}
