﻿using Vaichuve.Application.Ultility;

namespace Vaichuve.Application.DataModels
{
    public class ClimaDiarioModel : ClimaModel
    {
        public DateTime _DataAtual { get; private set; } = DateTime.Now;
        public string _CidadeAtual { get; private set; } = string.Empty;
        public string _EstadoAtual { get; private set; } = string.Empty;

        public ClimaModel _ClimaManha { get; private set; } = new ClimaModel();
        public ClimaModel _ClimaTarde { get; private set; } = new ClimaModel();
        public ClimaModel _ClimaNoite { get; private set; } = new ClimaModel();

        public ClimaDiarioModel(DateTime DataDoClima,
                                string Cidade,
                                string Estado,
                                int Temperatura,
                                string Descricao,
                                int HumidadeDoAr,
                                ClimaModel ClimaManha,
                                ClimaModel ClimaTarde,
                                ClimaModel ClimaNoite)
        {
            _DataAtual = DataDoClima;
            _CidadeAtual = Cidade;
            _EstadoAtual = Estado;
            _TemperaturaEmC = Temperatura;
            _Descricao = Descricao;
            _HumidadeDoAr = HumidadeDoAr;
            _ClimaManha = ClimaManha;
            _ClimaTarde = ClimaTarde;
            _ClimaNoite = ClimaNoite;
        }

        public ClimaDiarioModel(
                               string Cidade,
                               string Estado,
                               int Temperatura,
                               string Descricao,
                               int HumidadeDoAr,
                               ClimaModel ClimaManha,
                               ClimaModel ClimaTarde,
                               ClimaModel ClimaNoite)
        {
            _CidadeAtual = Cidade;
            _EstadoAtual = Estado;
            _TemperaturaEmC = Temperatura;
            _Descricao = Descricao;
            _HumidadeDoAr = HumidadeDoAr;
            _ClimaManha = ClimaManha;
            _ClimaTarde = ClimaTarde;
            _ClimaNoite = ClimaNoite;
        }


        public string RetornaData()
        {
            return Conversores.RetornaDiaDaSemanaEmPortugues(_DataAtual.DayOfWeek)
                + ", " + _DataAtual.Day
                + " de " + Conversores.RetornaMesEmPortugues(_DataAtual.Month);
        }

        public string RetornaClimaDaManha()
        {
            return "Na manhã de " + RetornaData() + "temos a temperatura de " + _ClimaManha.RetornaClimaComDescricao();
        }
        public string RetornaClimaDaTarde()
        {
            return "Na manhã de " + RetornaData() + "temos a temperatura de " + _ClimaTarde.RetornaClimaComDescricao();
        }
        public string RetornaClimaDaNoite()
        {
            return "Na manhã de " + RetornaData() + "temos a temperatura de " + _ClimaNoite.RetornaClimaComDescricao();
        }
    }
}
