﻿using Supabase;
using Vaichuve.Application.DataModels;
using Vaichuve.Application.Ultility;
using Vaichuve.Data.Entities;
using Vaichuve.Data.Entities.supabase;
using Vaichuve.Data.Entities.wttr;
using Vaichuve.Data.Services;

namespace Vaichuve.Application.Services
{
    public class DataService
    {
        SupabaseDatabaseService _supabaseData;
        WttrService _wttrService;

        CidadeEntityModel? cidades = null;
        List<ClimaJson> _supabaseClimas = new List<ClimaJson>();


        public DataService(SupabaseDatabaseService supabaseDatabaseService, WttrService wttrService)
        {
            _supabaseData = supabaseDatabaseService;
            _wttrService = wttrService;
        }
        private async Task BuscaCidadesProxDadosSupaBase(double lat, double log)
        {
            if (cidades == null)
            {
                cidades = await _supabaseData.RetornaCidadesMaisProximas(lat, log);
            }

            _supabaseClimas = await _supabaseData.RetornaHistoricoDeClimasParaCidade(cidades);
        }

        public async Task<ClimaDiarioModel> retornaClimaDoDia(double lat, double log)
        {
            cidades = await _supabaseData.RetornaCidadesMaisProximas(lat, log);

            WttrModel ModeloWttr = await _wttrService.RetornaClimaDoDiaParaCidadeAtual(cidades);

            ClimaModel ClimaManha = new ClimaModel()
            {
                _TemperaturaEmC = int.Parse(ModeloWttr.weather.FirstOrDefault().hourly.FirstOrDefault().FeelsLikeC),
                _Descricao = Conversores.RetornaDescricaoDoTempoEmPortuguesComBaseNoCodigo(ModeloWttr.weather.FirstOrDefault().hourly.FirstOrDefault().weatherCode)
            };

            ClimaModel ClimaTarde = new ClimaModel()
            {
                _TemperaturaEmC = int.Parse(ModeloWttr.weather.FirstOrDefault().hourly.ElementAtOrDefault(3).FeelsLikeC),
                _Descricao = Conversores.RetornaDescricaoDoTempoEmPortuguesComBaseNoCodigo(ModeloWttr.weather.FirstOrDefault().hourly.ElementAtOrDefault(3).weatherCode)
            };

            ClimaModel ClimaNoite = new ClimaModel()
            {
                _TemperaturaEmC = int.Parse(ModeloWttr.weather.FirstOrDefault().hourly.LastOrDefault().FeelsLikeC),
                _Descricao = Conversores.RetornaDescricaoDoTempoEmPortuguesComBaseNoCodigo(ModeloWttr.weather.FirstOrDefault().hourly.LastOrDefault().weatherCode)
            };

            ClimaDiarioModel retorno = new ClimaDiarioModel(cidades.DadosDaCidadeReal.nome,
                                                            Conversores.RetornaUfPorId(cidades.DadosDaCidadeReal.uf),
                                                            int.Parse(ModeloWttr.current_condition.FirstOrDefault().FeelsLikeC),
                                                            Conversores.RetornaDescricaoDoTempoEmPortuguesComBaseNoCodigo(ModeloWttr.current_condition.FirstOrDefault().weatherCode),
                                                            int.Parse(ModeloWttr.current_condition.FirstOrDefault().humidity),
                                                            ClimaManha, ClimaTarde, ClimaNoite);

            return retorno;
        }

        public async Task<List<ClimaDiarioModel>> RetornaHistoricoDeClimas(double lat, double log)
        {
            if (!_supabaseClimas.Any()) await BuscaCidadesProxDadosSupaBase(lat, log);

            List<ClimaDiarioModel> retorno = new List<ClimaDiarioModel>();

            foreach (ClimaJson _climaJson in _supabaseClimas)
            {

                ClimaDiarioModel clima = new ClimaDiarioModel(
                                                         DateTimeOffset.FromUnixTimeSeconds(_climaJson.dados_api.current.dt).DateTime,
                                                         cidades.DadosDaCidadeReal.nome,
                                                         Conversores.RetornaUfPorId(cidades.DadosDaCidadeReal.uf),
                                                         (int)_climaJson.dados_api.current.temp,
                                                         _climaJson.dados_api.current.weather.FirstOrDefault().description,
                                                         _climaJson.dados_api.current.humidity,
                                                         new ClimaModel(), new ClimaModel(), new ClimaModel());

                retorno.Add(clima);
            }

            return retorno;
        }

        public async Task<List<ClimaDiarioModel>> RetornaPrevisoesDeClima(double lat, double log)
        {
            if (!_supabaseClimas.Any()) await BuscaCidadesProxDadosSupaBase(lat, log);

            List<ClimaDiarioModel> retorno = new List<ClimaDiarioModel>();

            ClimaJson referencia = _supabaseClimas.FirstOrDefault();

            foreach (Daily d in referencia.dados_api.daily)
            {

                if (DateTimeOffset.FromUnixTimeSeconds(d.dt) > DateTime.Now)
                {
                    ClimaDiarioModel clima = new ClimaDiarioModel(
                                                        DateTimeOffset.FromUnixTimeSeconds(d.dt).DateTime,
                                                        "",
                                                        "",
                                                        (int)d.temp.day,
                                                         d.summary,
                                                        d.humidity,
                                                        new ClimaModel(), new ClimaModel(), new ClimaModel());

                    retorno.Add(clima);
                }
            }
            return retorno;
        }

        public async Task<List<EstadoModel>> RetornaTodosEstados()
        {
            List<EstadoModel> retorno = new List<EstadoModel>();
            List<SupabaseModels.Estado> dados = await _supabaseData.RetornaTodosEstados();

            foreach (SupabaseModels.Estado e in dados)
            {
                var estado = new EstadoModel()
                {
                    Id = e.id,
                    Name = e.nome,
                    Uf = e.uf
                };
                retorno.Add(estado);
            }

            return retorno;
        }

        public async Task<List<CidadeModel>> RetornaTodasCidadesDoEstado(int EstadoId)
        {
            List<CidadeModel> cidadeModels = new List<CidadeModel>();

            List<SupabaseModels.Cidade> dados = await _supabaseData.RetornaTodasCidadesDoEstado(EstadoId);

            foreach (SupabaseModels.Cidade c in dados)
            {
                var cid = new CidadeModel()
                {
                    EstadoId = EstadoId,
                    Id = c.id,
                    lat = c.latitude,
                    lon = c.longitude,
                    nome = c.nome,
                };
                cidadeModels.Add(cid);
            }

            return cidadeModels;
        }
    }
}
