﻿namespace Vaichuve.Application.Ultility
{
    public static class Conversores
    {
        public static string RetornaDiaDaSemanaEmPortugues(DayOfWeek dayOfWeek)
        {
            switch (dayOfWeek)
            {
                case DayOfWeek.Sunday: return "Domingo";
                case DayOfWeek.Monday: return "Segunda-Feira";
                case DayOfWeek.Tuesday: return "Terça-Feira";
                case DayOfWeek.Wednesday: return "Quarta-Feira";
                case DayOfWeek.Thursday: return "Quinta-Feira";
                case DayOfWeek.Friday: return "Sexta-Feira";
                case DayOfWeek.Saturday: return "Sábado";
                default: return "Erro: Não existe dia correspondente.";
            }
        }

        public static string RetornaMesEmPortugues(int NumeroDoMes)
        {
            switch (NumeroDoMes)
            {
                case 1: return "Janeiro";
                case 2: return "Fevereiro";
                case 3: return "Março";
                case 4: return "Abril";
                case 5: return "Maio";
                case 6: return "Junho";
                case 7: return "Julho";
                case 8: return "Agosto";
                case 9: return "Setembro";
                case 10: return "Outubro";
                case 11: return "Novembro";
                case 12: return "Dezembro";
                default: return "Erro: Não existe mês correspondente.";
            }
        }
        public static string RetornaDescricaoDoTempoEmPortuguesComBaseNoCodigo(string code)
        {
            switch (code)
            {
                case "113": return "Ensolarado";
                case "116": return "Parcialmente Nublado";
                case "119": return "Nublado";
                case "122": return "Muito Nublado";
                case "143": return "Nevoeiro";
                case "176": return "Chuva Leve";
                case "179": return "Chuviscos com Granizo Leve";
                case "182": return "Granizo Leve";
                case "185": return "Granizo Leve";
                case "200": return "Trovoadas com Chuviscos";
                case "227": return "Neve Leve";
                case "230": return "Neve Pesada";
                case "248": return "Nevoeiro";
                case "260": return "Nevoeiro";
                case "263": return "Chuviscos Leves";
                case "266": return "Chuva Leve";
                case "281": return "Granizo Leve";
                case "284": return "Granizo Leve";
                case "293": return "Chuva Leve";
                case "296": return "Chuva Leve";
                case "299": return "Chuva Pesada";
                case "302": return "Chuva Forte";
                case "305": return "Chuva Pesada";
                case "308": return "Chuva Forte";
                case "311": return "Granizo Leve";
                case "314": return "Granizo Leve";
                case "317": return "Granizo Leve";
                case "320": return "Neve Leve";
                case "323": return "Nevasca Leve";
                case "326": return "Nevasca Leve";
                case "329": return "Neve Pesada";
                case "332": return "Neve Pesada";
                case "335": return "Nevasca Pesada";
                case "338": return "Neve Pesada";
                case "350": return "Granizo Leve";
                case "353": return "Chuviscos Leves";
                case "356": return "Chuva Pesada";
                case "359": return "Chuva Forte";
                case "362": return "Chuviscos com Granizo Leve";
                case "365": return "Chuviscos com Granizo Leve";
                case "368": return "Nevasca Leve";
                case "371": return "Nevasca Pesada";
                case "374": return "Chuviscos com Granizo Leve";
                case "377": return "Granizo Leve";
                case "386": return "Trovoadas com Chuviscos";
                case "389": return "Trovoadas com Chuva Forte";
                case "392": return "Trovoadas com Nevasca";
                case "395": return "Nevasca Pesada";
                default: return "Erro: Código desconhecido";
            }
        }
        public static string RetornaUfPorId(int id)
        {
            switch (id)
            {
                case 1:
                    return "AC";
                case 2:
                    return "AL";
                case 3:
                    return "AM";
                case 4:
                    return "AP";
                case 5:
                    return "BA";
                case 6:
                    return "CE";
                case 7:
                    return "DF";
                case 8:
                    return "ES";
                case 9:
                    return "GO";
                case 10:
                    return "MA";
                case 11:
                    return "MG";
                case 12:
                    return "MS";
                case 13:
                    return "MT";
                case 14:
                    return "PA";
                case 15:
                    return "PB";
                case 16:
                    return "PE";
                case 17:
                    return "PI";
                case 18:
                    return "PR";
                case 19:
                    return "RJ";
                case 20:
                    return "RN";
                case 21:
                    return "RO";
                case 22:
                    return "RR";
                case 23:
                    return "RS";
                case 24:
                    return "SC";
                case 25:
                    return "SE";
                case 26:
                    return "SP";
                case 27:
                    return "TO";
                case 99:
                    return "EX";
                default:
                    return "EX";
            }
        }

        public static int GetEstadoIdBySigla(string sigla)
        {
            switch (sigla)
            {
                case "AC":
                    return 1;
                case "AL":
                    return 2;
                case "AM":
                    return 3;
                case "AP":
                    return 4;
                case "BA":
                    return 5;
                case "CE":
                    return 6;
                case "DF":
                    return 7;
                case "ES":
                    return 8;
                case "GO":
                    return 9;
                case "MA":
                    return 10;
                case "MG":
                    return 11;
                case "MS":
                    return 12;
                case "MT":
                    return 13;
                case "PA":
                    return 14;
                case "PB":
                    return 15;
                case "PE":
                    return 16;
                case "PI":
                    return 17;
                case "PR":
                    return 18;
                case "RJ":
                    return 19;
                case "RN":
                    return 20;
                case "RO":
                    return 21;
                case "RR":
                    return 22;
                case "RS":
                    return 23;
                case "SC":
                    return 24;
                case "SE":
                    return 25;
                case "SP":
                    return 26;
                case "TO":
                    return 27;
                case "EX":
                    return 99;
                default:
                    return 99; // Caso a sigla não seja encontrada, retorna 99 como padrão
            }
        }
    }
}
