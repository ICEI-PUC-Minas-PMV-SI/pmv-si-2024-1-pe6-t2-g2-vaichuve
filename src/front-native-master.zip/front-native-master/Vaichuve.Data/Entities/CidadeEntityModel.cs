﻿using static Vaichuve.Data.Entities.supabase.SupabaseModels;

namespace Vaichuve.Data.Entities
{
    public  class CidadeEntityModel
    {
        public Cidade DadosDaCidadeReal { get; set; } = new Cidade();
        public Cidade CidadeMaisProximaQuePossuiDadosClima { get; set; } = new Cidade();
    }
}
