﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;
using System.Net.Http.Json;
using System.Text.Json;

namespace Vaichuve.Data.Entities.supabase
{
    public class SupabaseModels
    {
        [Table("cidade")]
        public class Cidade : BaseModel
        {
            [PrimaryKey("id")]
            public int id { get; set; }
            public string nome { get; set; } = string.Empty;
            public int uf { get; set; }
            public double latitude { get; set; }
            public double longitude { get; set; }
        }

        [Table("estado")]
        public class Estado : BaseModel
        {
            [PrimaryKey("id")]
            public int id { get; set; }
            [Column("nome")]
            public string? nome { get; set; }
            [Column("uf")]
            public string? uf { get; set; }
            [Column("ibge")]
            public int? ibge { get; set; }
            [Column("pais")]
            public int? pais { get; set; }
            [Column("ddd")]
            public List<int?>? ddd { get; set; }
        }

        [Table("clima")]
        public class Clima : BaseModel
        {
            [PrimaryKey("id")]
            public long Id { get; set; }

            [Column("dados_api")]
            public string DadosApi { get; set; }

            [Column("cidade")]
            public int Cidade { get; set; }

            [Column("created_at")]
            public DateTime CreatedAt { get; set; }
        }
    }
}
