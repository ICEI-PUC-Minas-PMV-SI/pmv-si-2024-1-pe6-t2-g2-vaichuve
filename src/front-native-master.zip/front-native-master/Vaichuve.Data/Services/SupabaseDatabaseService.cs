﻿using System.Text.Json;
using Vaichuve.Data.Entities;
using Vaichuve.Data.Entities.supabase;
using static Vaichuve.Data.Entities.supabase.SupabaseModels;

namespace Vaichuve.Data.Services
{
    public class SupabaseDatabaseService
    {
        public readonly Supabase.Client _supabaseClient;
        public HttpClient _httpClient = new HttpClient();

        string url = "https://srejuickxwniocpkimuf.supabase.co";
        string key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNyZWp1aWNreHduaW9jcGtpbXVmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTA5NzYzMTYsImV4cCI6MjAyNjU1MjMxNn0.3kqbjnPCe1_Gq1_gGW5gvbc4PMKX-EDdg4jcO0zSB9s";

        public SupabaseDatabaseService(Supabase.Client client)
        {
            _supabaseClient = client;
        }

        public async Task<CidadeEntityModel> RetornaCidadesMaisProximas(double lat, double lng)
        {
            CidadeEntityModel retorno = new();

            // As latitudes e longitudes estão invertidas pq o supabase usa esse tipo de notação
            var result1 = await _supabaseClient.Rpc("real_nearby_city", new Dictionary<string, object> { { "lat", lng }, { "long", lat } });
            var result2 = await _supabaseClient.Rpc("nearby_city", new Dictionary<string, object> { { "lat", lng }, { "long", lat } });

            if (result1 == null || result2 == null || result1.Content == null || result2.Content == null) return retorno;

            List<Cidade> tempretorno1 = JsonSerializer.Deserialize<List<Cidade>>(result1.Content);
            List<Cidade> tempretorno2 = JsonSerializer.Deserialize<List<Cidade>>(result2.Content);

            if (tempretorno1 == null || tempretorno2 == null || (tempretorno1.Count == 0 && tempretorno2.Count() == 0)) return retorno;

            retorno.DadosDaCidadeReal = tempretorno1.FirstOrDefault();
            retorno.CidadeMaisProximaQuePossuiDadosClima = tempretorno2.FirstOrDefault();

            return retorno;
        }

        public async Task<List<ClimaJson>> RetornaHistoricoDeClimasParaCidade(CidadeEntityModel cidadeEntity)
        {
            HttpRequestMessage _httpCall = new HttpRequestMessage(HttpMethod.Get, "https://srejuickxwniocpkimuf.supabase.co/rest/v1/clima?select=dados_api&cidade=eq." + cidadeEntity.CidadeMaisProximaQuePossuiDadosClima.id + "&limit=30&order=id.desc");
            _httpCall.Headers.Add("apikey", key);

            var r = await _httpClient.SendAsync(_httpCall);
            string responseBody = await r.Content.ReadAsStringAsync();
            var retorno = JsonSerializer.Deserialize<List<ClimaJson>>(responseBody);

            if (retorno == null) return new List<ClimaJson>();

            return retorno;
        }

        public async Task<List<Estado>> RetornaTodosEstados()
        {
            HttpRequestMessage _httpCall = new HttpRequestMessage(HttpMethod.Get, "https://srejuickxwniocpkimuf.supabase.co/rest/v1/estado?select=*");

            _httpCall.Headers.Add("apikey", key);

            var r = await _httpClient.SendAsync(_httpCall);
            string responseBody = await r.Content.ReadAsStringAsync();

            List<Estado> retorno = JsonSerializer.Deserialize<List<Estado>>(responseBody);

            return retorno;
        }

        public async Task<List<Cidade>> RetornaTodasCidadesDoEstado(int EstadoId)
        {
            var result = await _supabaseClient.From<Cidade>().Where(x => x.uf == EstadoId).Get();

            if (result == null) return new List<Cidade>();

            return JsonSerializer.Deserialize<List<Cidade>>(result.Content);
        }
    }
}
