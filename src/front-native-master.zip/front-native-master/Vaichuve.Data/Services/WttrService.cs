﻿using System.Net.Http.Json;
using Vaichuve.Data.Entities;
using Vaichuve.Data.Entities.wttr;
using static Vaichuve.Data.Entities.supabase.SupabaseModels;

namespace Vaichuve.Data.Services
{
    public class WttrService
    {
        HttpClient _httpClient = new HttpClient();

        public async Task<WttrModel> RetornaClimaDoDiaParaCidadeAtual(CidadeEntityModel cidades)
        {
            WttrModel clima = await _httpClient.GetFromJsonAsync<WttrModel>("https://wttr.in/" + cidades.DadosDaCidadeReal.nome + "?format=j1");

            if (clima == null) return new WttrModel();

            return clima;
        }
    }
}
