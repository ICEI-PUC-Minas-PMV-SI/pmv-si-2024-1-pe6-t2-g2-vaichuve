﻿using Supabase;
using System.Net.Http.Json;
using System.Text.Json;
using Vaichuve.Application.DataModels;
using Vaichuve.Application.Services;
using Vaichuve.Data.Entities;
using Vaichuve.Data.Entities.supabase;
using Vaichuve.Data.Entities.wttr;
using Vaichuve.Data.Services;
// --

var options = new SupabaseOptions
{
    AutoRefreshToken = true,
    AutoConnectRealtime = true,
};


string url = "https://srejuickxwniocpkimuf.supabase.co";
string key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNyZWp1aWNreHduaW9jcGtpbXVmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTA5NzYzMTYsImV4cCI6MjAyNjU1MjMxNn0.3kqbjnPCe1_Gq1_gGW5gvbc4PMKX-EDdg4jcO0zSB9s";
Client _supabaseClient = new Client(url, key, options);
await _supabaseClient.InitializeAsync();


HttpClient _httpClient = new HttpClient();
SupabaseDatabaseService _supaService = new SupabaseDatabaseService(_supabaseClient);
WttrService _wttrService = new WttrService();

//CidadeEntityModel cidade = await _supaService.RetornaCidadesMaisProximas(-19.917299, -43.934559);

//HttpRequestMessage _httpCall = new HttpRequestMessage(HttpMethod.Get, "https://srejuickxwniocpkimuf.supabase.co/rest/v1/clima?select=dados_api&cidade=eq." + cidade.CidadeMaisProximaQuePossuiDadosClima.id + "&limit=30");
//_httpCall.Headers.Add("apikey", key);

try
{
    //var r = await _httpClient.SendAsync(_httpCall);
    //string responseBody = await r.Content.ReadAsStringAsync();
    //var content = JsonSerializer.Deserialize<List<ClimaJson>>(responseBody);
    //WttrModel clima = await _httpClient.GetFromJsonAsync<WttrModel>("https://wttr.in/" + cidade.DadosDaCidadeReal.nome + "?format=j1");

    //DataService _dataService = new DataService(_supaService, _wttrService);
    var r = await _supaService.RetornaTodosEstados();

    var f = await _supaService.RetornaTodasCidadesDoEstado( r.Where(x => x.uf == "MG").FirstOrDefault().id );
    
    //ClimaDiarioModel r = await _dataService.retornaClimaDoDia(-19.917299, -43.934559);
    //List<ClimaDiarioModel> listR = await _dataService.RetornaHistoricoDeClimas(-19.917299, -43.934559);

    Console.WriteLine("Breakpoint!");
}
catch (Exception ex)
{
    Console.WriteLine(ex.ToString());
}

