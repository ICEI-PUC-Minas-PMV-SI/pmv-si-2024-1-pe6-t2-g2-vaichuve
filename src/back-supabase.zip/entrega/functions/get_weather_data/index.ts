import { corsHeaders } from '../_shared/cors.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js';
console.log("Hello from Functions!")

Deno.serve(async (req) => {
  if (req.method === "OPTIONS"){
    return new Response (null, {
      headers: {...corsHeaders, 'Allow': 'POST'},
    })
  }
  const apiKey = Deno.env.get("OPENWEATHERMAP_API_KEY");
  if (!apiKey) {
    throw new Error("OPENWEATHERMAP_API_KEY is not set")
  }

  console.log(req)
  const { lat, lon } = await req.json();

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
  )

  const { data: dispositivos, error } = await supabase.from('dispositivos').select(`
    cidade (
      id,
      latitude,
      longitude
    )
  `);

  if (error) {
    return new Response(JSON.stringify(error), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }

  // Unique cities
  const cities = dispositivos.map(dispositivo => dispositivo.cidade);
  
  console.log("CIDADE")


  for (const city of cities) {
    const { latitude, longitude } = city;
    const response = await fetch(`https://api.openweathermap.org/data/3.0/onecall?lat=${latitude}&lon=${longitude}&appid=${apiKey}&units=metric&lang=pt_br`);
    const weatherData = await response.json();
    console.log("CIDADE", city, { latitude, longitude }, weatherData);

    if (!weatherData.current) {
      continue;
    }

    // Insert weather data into the database
    const { data: insertedData, error } = await supabase.from('clima').insert({
      cidade: city.id,
      dados_api: weatherData,
    });

    if (error) {
      return new Response(JSON.stringify(error), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      });
    }
  }

  

  // Make a request to the OpenWeatherMap API
  // const response = await fetch(`https://api.openweathermap.org/data/3.0/onecall?lat=${lat}&lon=${lon}&appid=${apiKey}`);
  // const weatherData = await response.json();
  
  const data = {
    message: `Hello!`,
    // weatherData,
  }
  return new Response(JSON.stringify(data), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    status: 200,
  });
});