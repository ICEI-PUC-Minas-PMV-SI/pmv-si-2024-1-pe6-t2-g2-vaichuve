CREATE OR REPLACE FUNCTION nearby_city(lat FLOAT, long FLOAT)
RETURNS TABLE (
  id BIGINT,
  nome VARCHAR,
  uf BIGINT,
  ibge INTEGER,
  lat_lon POINT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  dist_meters DOUBLE PRECISION
)
LANGUAGE sql
AS $$
  SELECT
    id,
    nome,
    uf,
    ibge,
    lat_lon,
    latitude,
    longitude,
    (lat_lon <-> POINT(long, lat)) * 111195 AS dist_meters
  FROM
    cidade
  WHERE
    id IN (SELECT DISTINCT cidade FROM clima)
  ORDER BY
    lat_lon <-> POINT(long, lat)
  LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION historical_data(id_cidade BIGINT)
RETURNS TABLE (
  id BIGINT,
  dados_api JSON,
  cidade BIGINT
)
LANGUAGE sql
AS $$
  SELECT
    DISTINCT ON (date_trunc('day', created_at))
    id,
    dados_api,
    cidade
  FROM
    clima
  WHERE
    cidade = id_cidade
  ORDER BY
    date_trunc('day', created_at) DESC,
    created_at DESC
  LIMIT 30
$$;


create extension pg_cron with schema extensions;

grant usage on schema cron to postgres;
grant all privileges on all tables in schema cron to postgres;

SELECT cron.schedule(
    'invoke-function-daily',
    '0 0 * * *', -- every day at midnight
    $$
    SELECT
      net.http_post(
          url:='SUPABASE_HOST/functions/v1/get_weather_data',
          headers:='{"Content-Type": "application/json", "Authorization": "Bearer ANON_KEY", "apikey": "SERVICE_KEY"}'::jsonb,
          body:=jsonb_build_object('time', now())
      ) AS request_id;
    $$
);