'use client'

import { configProvider } from "@/app/config"
import { createClient } from "@supabase/supabase-js"
import { createContext, useContext, useEffect, useState } from "react"

const supabase = createClient(configProvider.SUPABASE_URL, configProvider.SUPABASE_KEY)

export interface ILocation {
  id?: number // representa o id da cidade mais próxima que possui informações de clima e histórico
  realCity?: { id: number, latitude: number, longitude: number, distanceInKm: number, city: string, region: string }  // representa a cidade real mais próxima
  city: string
  region: string
  latitude: number
  longitude: number
  origin: 'ip' | 'user_selection'
}
export interface ICurrentLocationContext {
  setCurrentLocation: (localization: ILocation) => Promise<void>
  currentLocation: ILocation | null
  isLoading: boolean
}

export const CurrentLocationContext = createContext<ICurrentLocationContext>({} as ICurrentLocationContext)


const getLocationByInternet = async () => {
  const request = await fetch('https://ipinfo.io/json')
  const response = await request.json()

  const latitude = parseFloat(response.loc.split(',')[1])
  const longitude = parseFloat(response.loc.split(',')[0])

  const { data } = await supabase.rpc('nearby_city', {
    lat: latitude,
    long: longitude,
  })

  const estadoResponse = await supabase
    .from('estado')
    .select('*')
    .eq('id', data[0].uf)
    .limit(1)

  return {
    city: data[0].nome,
    region: estadoResponse.data?.[0].uf,
    latitude,
    longitude,
    origin: 'ip'
  } as ILocation
}

/**
 * Retorna a cidade mais próxima da localização fornecida que possui informações de clima e histórico
 * 
 * Essa etapa é necessária pois o clima e o histórico são pesquisados com base no id da cidade
 * @param latitude 
 * @param longitude 
 * @returns number
 */
const getCityId = async (latitude: number, longitude: number) => {
  const { data } = await supabase.rpc('nearby_city', {
    lat: latitude,
    long: longitude,
  })

  return data[0].id
}

const getRealCity = async (latitude: number, longitude: number) => {
  const { data } = await supabase.rpc('real_nearby_city', {
    lat: latitude,
    long: longitude,
  })


  const estadoResponse = await supabase
    .from('estado')
    .select('*')
    .eq('id', data[0].uf)
    .limit(1)


  return {
    id: data[0].id,
    latitude: data[0].latitude,
    longitude: data[0].longitude,
    distanceInKm: data[0].dist_meters / 1000,
    city: data[0].nome,
    region: estadoResponse.data?.[0].uf,
  }
}

/**
 * Diz a localização do usuário, ela pode vir de dois lugares:
 * 1. Da api ipinfo.io, que retorna a localização do usuário baseado no ip
 * 2. Do cache do navegador, que é salvo quando o usuário seleciona uma localização ou quando a api ipinfo.io é chamada
 */
function useCurrentLocationHook() {
  const [location, setLocation] = useState<ILocation | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const setCurrentLocation = async (localization: ILocation) => {
    localization.id = await getCityId(localization.latitude, localization.longitude)
    localization.realCity = await getRealCity(localization.latitude, localization.longitude)
    localStorage.setItem('location', JSON.stringify(localization))
    setLocation(localization)
  }

  useEffect(() => {
    const cachePosition = localStorage.getItem('location')
    if (cachePosition) {
      setLocation(JSON.parse(cachePosition))
      setIsLoading(false)
      return
    }

    getLocationByInternet()
      .then((response) => {
        setCurrentLocation(response)
      })
    .finally(() => setIsLoading(false))
  }, [])


  return {
    currentLocation: location,
    setCurrentLocation,
    isLoading,
  }
}


export function CurrentLocationProvider({ children }: { children: React.ReactNode }) {
  const locationHook = useCurrentLocationHook()
  return (
    <CurrentLocationContext.Provider value={locationHook}>
      {children}
    </CurrentLocationContext.Provider>
  )
}

export const useCurrentLocation = () => useContext(CurrentLocationContext)