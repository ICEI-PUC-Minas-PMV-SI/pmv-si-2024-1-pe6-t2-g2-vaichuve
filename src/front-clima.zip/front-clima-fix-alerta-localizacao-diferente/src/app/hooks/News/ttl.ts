export class Storage {
  static save(key: string, value: Object, ttl: number) {
    const expiresAt = Date.now() / 1000 + ttl
    localStorage.setItem(key, JSON.stringify({ value, expiresAt }))
  }

  static get(key: string) {
    const itemStr = localStorage.getItem(key)
    if (!itemStr) {
      return null
    }

    const item = JSON.parse(itemStr)
    if (Date.now() / 1000 > item.expiresAt) {
      localStorage.removeItem(key)
      return null
    }

    return item.value
  }
}