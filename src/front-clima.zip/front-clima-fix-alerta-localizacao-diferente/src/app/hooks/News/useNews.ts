import { configProvider } from "@/app/config"
import { createClient } from "@supabase/supabase-js"
import { useEffect, useState } from "react"
import { Storage } from "./ttl"

export interface INews {
  title: string
  description: string
  url: string
  source: {
    id: string
  }
}

const supabase = createClient(configProvider.SUPABASE_URL, configProvider.SUPABASE_KEY)

export function useNews() {
  const [isLoading, setIsLoading] = useState(false)
  const [news, setNews] = useState<INews[]>([])

  useEffect(() => {
    setIsLoading(true)
    const cache = Storage.get('news')
    if(cache) {
      setNews(cache)
      setIsLoading(false)
      return
    }

    supabase.functions.invoke('get_news').then(({ data, error }) => {
      if(error) {
        return
      }
      const parser = new DOMParser()
      const parseString = (txt: string) => {
        const htmlDoc = parser.parseFromString(txt, 'text/html')
        return htmlDoc.body.innerText || htmlDoc.body.textContent || ''
      }

      const items = data.rss.channel.item.map((item: Record<string, string>) => ({
        title: parseString(item.title),
        description: parseString(item.description).replace(/ ?leia mais ?(.+)/gmi, ''),
        url: item.link,
        source: {
          id: 'Folha de São Paulo',
        }
      }))

      const tenMinutes = 60 * 10
      Storage.save('news', items, tenMinutes)
      setNews(items)
    })
    .finally(() => setIsLoading(false))
  }, [])

  return {
    news,
    isLoading,
  }
}