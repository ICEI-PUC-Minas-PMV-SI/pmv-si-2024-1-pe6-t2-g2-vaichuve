import { configProvider } from "@/app/config"
import { createClient } from "@supabase/supabase-js"
import { useEffect, useState } from "react"

const supabase = createClient(configProvider.SUPABASE_URL, configProvider.SUPABASE_KEY);

interface Weather {
  id: number
  main: string
  description: string
  icon: string
}

interface Current {
  dt: number
  sunrise: number
  sunset: number
  temp: number
  feels_like: number
  pressure: number
  humidity: number
  dew_point: number
  uvi: number
  clouds: number
  visibility: number
  wind_speed: number
  wind_deg: number
  weather: Weather[]
}

interface Hourly {
  dt: number
  temp: number
  feels_like: number
  pressure: number
  humidity: number
  dew_point: number
  uvi: number
  clouds: number
  visibility: number
  wind_speed: number
  wind_deg: number
  wind_gust: number
  weather: Weather[]
  pop: number
}

interface Temp {
  day: number
  min: number
  max: number
  night: number
  eve: number
  morn: number
}

interface FeelsLike {
  day: number
  night: number
  eve: number
  morn: number
}

interface Daily {
  dt: number
  sunrise: number
  sunset: number
  moonrise: number
  moonset: number
  moon_phase: number
  summary: string
  temp: Temp
  feels_like: FeelsLike
  pressure: number
  humidity: number
  dew_point: number
  wind_speed: number
  wind_deg: number
  wind_gust: number
  weather: Weather[]
  clouds: number
  pop: number
  uvi: number
}

interface DadosApi {
  lat: number
  lon: number
  timezone: string
  timezone_offset: number
  current: Current
  hourly: Hourly[]
  daily: Daily[]
}

export interface CityWeather {
  id: number
  dados_api: DadosApi
  cidade: number
}

export function useHistoricalWeather() {
  const [selectedCity, setSelectedCity] = useState<number | null>(null)
  const [loading, setLoading] = useState<boolean>(false)
  const [historicalData, sethistoricalData] = useState<CityWeather[]>([])

  useEffect(() => {
    if(!selectedCity) return

    async function getHistoricalWeather() {
      const { data, error} = await supabase.rpc('historical_data', {
        id_cidade: selectedCity,
      })

      if(error) {
        console.error(error)
        return
      }

      sethistoricalData(data.slice(0, 15))
    }

    setLoading(true)
    getHistoricalWeather()
      .finally(() => setLoading(false))
  }, [selectedCity])

  return {
    selectedCity,
    setSelectedCity,
    loading,
    historicalData,
  }
}