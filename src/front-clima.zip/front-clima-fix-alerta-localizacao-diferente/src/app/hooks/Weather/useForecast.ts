import { configProvider } from "@/app/config"
import { createClient } from "@supabase/supabase-js"
import { useEffect, useState } from "react"
import { CityWeather } from "./useHistoricalWeather"

const supabase = createClient(configProvider.SUPABASE_URL, configProvider.SUPABASE_KEY);

export function useForecast() {
  const [selectedCity, setSelectedCity] = useState<number | null>(null)
  const [loading, setLoading] = useState<boolean>(false)
  const [forecast, setForecast] = useState<CityWeather | null>(null)

  useEffect(() => {
    if(!selectedCity) return

    async function getForecast() {
      const { data, error } = await supabase
        .from('clima')
        .select('*')
        .eq('cidade', selectedCity)
        .order('created_at', { ascending: false })
        .limit(1)

      if (error) {
        console.error('Error fetching data:', error)
        return
      }
      console.log('First record for specific id:', data)
      setForecast(data[0])
    }

    setLoading(true)
    getForecast()
      .finally(() => setLoading(false))
  }, [selectedCity])

  return {
    setSelectedCity,
    loading,
    forecast,
  }
}