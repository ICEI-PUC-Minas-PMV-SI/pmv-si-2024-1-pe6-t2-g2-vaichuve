'use client'

import { ChakraProvider } from '@chakra-ui/react'
import { AcessibilityProvider } from '@/app/hooks/Acessibility/useAcessibility'
import { CurrentLocationProvider } from '@/app/hooks/CurrentLocation/useCurrentLocation'

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ChakraProvider>
      <AcessibilityProvider>
        <CurrentLocationProvider>
          {children}
        </CurrentLocationProvider>
      </AcessibilityProvider>
    </ChakraProvider>
  )
}