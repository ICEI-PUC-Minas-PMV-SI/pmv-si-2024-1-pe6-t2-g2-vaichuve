export const configProvider = {
    "SUPABASE_URL": "https://srejuickxwniocpkimuf.supabase.co",
    "SUPABASE_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNyZWp1aWNreHduaW9jcGtpbXVmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTA5NzYzMTYsImV4cCI6MjAyNjU1MjMxNn0.3kqbjnPCe1_Gq1_gGW5gvbc4PMKX-EDdg4jcO0zSB9s",
}