'use client'

import { ChakraProvider } from '@chakra-ui/react'
import { AcessibilityProvider } from '@/app/hooks/Acessibility/useAcessibility'

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ChakraProvider>
      <AcessibilityProvider>
        {children}
      </AcessibilityProvider>
    </ChakraProvider>
  )
}