import { useEffect, useState } from "react"

export interface INews {
  title: string
  description: string
  url: string
  source: {
    id: string
  }
}

const getCurrentDate = () => new Date().toISOString()
const datetimeDiffInHours = (dateInPast: string) => (Date.now() - new Date(dateInPast).getTime()) / 1000 / 60 / 60
const hasLessThan24Hours = (dateInPast: string) => datetimeDiffInHours(dateInPast) < 24

export function useNews() {
  const [isLoading, setIsLoading] = useState(false)
  const [news, setNews] = useState<INews[]>([])
  const [lastUpdated, setLastUpdated] = useState<string | null>(null)

  useEffect(() => {
    setIsLoading(true)
    const newInCache = localStorage.getItem("CURRENT_NEWS")
    const lastUpdated = localStorage.getItem("LATEST_UPDATED_NEWS")

    if (newInCache && lastUpdated && hasLessThan24Hours(lastUpdated)) {
      setNews(JSON.parse(newInCache))
      setLastUpdated(lastUpdated)
      setIsLoading(false)
      return
    }

    fetch('https://newsapi.org/v2/top-headlines?country=br&apiKey=006a4f804ce7415eaef54d7c38fd915c&category=general')
      .then((res) => res.json())
      .then((responseData) => {
        localStorage.setItem("CURRENT_NEWS", JSON.stringify(responseData.articles))
        localStorage.setItem("LATEST_UPDATED_NEWS", getCurrentDate())

        setNews(responseData.articles)
        setLastUpdated(getCurrentDate())
      })
      .finally(() => setIsLoading(false))
  }, [])

  return {
    news,
    isLoading,
    lastUpdated,
  }
}