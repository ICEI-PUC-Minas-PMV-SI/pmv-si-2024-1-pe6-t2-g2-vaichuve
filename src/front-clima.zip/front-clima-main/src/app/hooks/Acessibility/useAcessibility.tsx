'use client'

import { createContext, useContext, useEffect, useRef, useState } from "react"

export interface IAcessibilityContext {
  resetAcessibility: () => void
  isLoading: boolean
  fontSize: {
    value: number
    set: (value: number) => void
  }
  linesSize: {
    value: number
    set: (value: number) => void
  }
  betweenCharsSize: {
    value: number
    set: (value: number) => void
  }
}

export const AcessibilityContext = createContext<IAcessibilityContext>({} as IAcessibilityContext)

function getPercentage(value: number) {
  if (value < 50)
    return 80
  else if (value > 50)
    return 160
  else
    return 100
}

function getLetterSpacing(value: number) {
  if (value < 50)
    return -0.1
  else if (value > 50)
    return 0.1
  else
    return 0
}

function setAcessibility(fontSize: number, linesSize: number, betweenCharsSize: number) {
  document.body.style.fontSize = `${getPercentage(fontSize)}%`
  document.body.style.lineHeight = `${getPercentage(linesSize)}%`
  document.body.style.letterSpacing = `${getLetterSpacing(betweenCharsSize)}em`

  window.localStorage.setItem('fontSize', String(fontSize))
  window.localStorage.setItem('linesSize', String(linesSize))
  window.localStorage.setItem('betweenCharsSize', String(betweenCharsSize))
}

function loadFromStorage(key: string, defaultValue: number) {
  const value = window.localStorage.getItem(key)
  if (value)
    return Number(value)
  return defaultValue
}

function useAccessibilityHook() {
  const [fontSize, setFontSize] = useState<number>(50)
  const [linesSize, setLinesSize] = useState<number>(50)
  const [betweenCharsSize, setBetweenCharsSize] = useState<number>(50)
  const [isLoading, setIsLoading] = useState(true)
  const firstExec = useRef(true)

  useEffect(() => {
    if (firstExec.current) {
      firstExec.current = false;
      setFontSize(loadFromStorage('fontSize', 50))
      setLinesSize(loadFromStorage('linesSize', 50))
      setBetweenCharsSize(loadFromStorage('betweenCharsSize', 50))
      setIsLoading(false)
      return;
    }
    setAcessibility(
      fontSize,
      linesSize,
      betweenCharsSize,
    )
  }, [fontSize, linesSize, betweenCharsSize])

  const resetAcessibility = () => {
    setFontSize(50)
    setLinesSize(50)
    setBetweenCharsSize(50)
  }

  return {
    resetAcessibility,
    isLoading,
    fontSize: {
      value: fontSize,
      set: setFontSize,
    },
    linesSize: {
      value: linesSize,
      set: setLinesSize,
    },
    betweenCharsSize: {
      value: betweenCharsSize,
      set: setBetweenCharsSize,
    },
  }
}


export function AcessibilityProvider({ children }: { children: React.ReactNode }) {
  const acessibility = useAccessibilityHook()
  return (
    <AcessibilityContext.Provider value={acessibility}>
      {children}
    </AcessibilityContext.Provider>
  )
}

export const useAccessibility = () => useContext(AcessibilityContext)