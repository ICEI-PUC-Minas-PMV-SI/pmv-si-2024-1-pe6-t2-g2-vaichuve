"use client";

import {
  Box,
  Flex,
  Text,
  IconButton,
  Button,
  Stack,
  Collapse,
  Icon,
  Link,
  Popover,
  PopoverTrigger,
  PopoverContent,
  useColorModeValue,
  useBreakpointValue,
  useDisclosure,
  Card,
  CardBody,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Image,
  Grid,
  GridItem,
  Heading,
  Table,
  Thead,
  Tbody,
  Tfoot,
  Tr,
  Th,
  Td,
  TableCaption,
  TableContainer,
  Input
} from "@chakra-ui/react";
import {
  HamburgerIcon,
  CloseIcon,
  ChevronDownIcon,
  ChevronRightIcon,
} from '@chakra-ui/icons';
import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { configProvider } from './config';

const supabase = createClient(configProvider.SUPABASE_URL, configProvider.SUPABASE_KEY);

export default function WithSubnavigation() {
  const [historicalData, sethistoricalData] = useState(null as any)
  const [data, setData] = useState(null as any)
  const [dadosApi, setdadosApi] = useState(null as any)
  const [isLoading, setLoading] = useState(true)
  const { isOpen, onToggle } = useDisclosure();
  
  function getPercentage(value: any) {
    if (value < 50)
      return 80;
    else if (value > 50)
      return 160;
    else
      return 100;
  }

  function getLetterSpacing(value: any) {
    if (value < 50)
      return -0.1;
    else if (value > 50)
      return 0.1;
    else
      return 0;
  }
  function setAcessibility(fontSize: any, linesSize: any, betweenCharsSize: any) {
    document.body.style.fontSize = `${getPercentage(fontSize)}%`;
    document.body.style.lineHeight = `${getPercentage(linesSize)}%`;
    document.body.style.letterSpacing = `${getLetterSpacing(betweenCharsSize)}em`;
    
    localStorage.setItem('fontSize', fontSize);
    localStorage.setItem('linesSize', linesSize);
    localStorage.setItem('betweenCharsSize', betweenCharsSize);
  }
  useEffect(() => {
    const fs = localStorage.getItem('fontSize') ?? 50;
    const ls = localStorage.getItem('linesSize') ?? 50;
    const cs = localStorage.getItem('betweenCharsSize') ?? 50;
    setAcessibility(fs, ls, cs);
  }, []);

  useEffect(() => {
    async function main() {

      let override_geo = localStorage.getItem("selectedCity") as any;
      if (override_geo) {
        override_geo = JSON.parse(override_geo);
        console.log('OVERRIDE', override_geo);

        setData({
          city: override_geo.nome,
          region: override_geo.estado.nome
        });
        const loc = override_geo.lat_lon.replace('(', '').replace(')', '');
        const [long, lat] = loc.split(',');
        console.log(long, lat);

        const city_data = await supabase.rpc('nearby_city', {
          lat: parseFloat(lat),
          long: parseFloat(long)
        });

        if (city_data.error) {
          console.log('ERROR', city_data.error);
          return;
        }
        const closest_city = city_data.data[0];
        console.log('CITY DATA', city_data);

        const clima = await supabase
          .from('clima')
          .select('*')
          .eq('cidade', closest_city.id)
          .order('created_at', { ascending: false })
          .limit(10);

        if (clima.error) {
          console.error('Error fetching data:', clima.error);
        } else {
          console.log('Last 10 records for specific id:', clima.data);
        }
        setdadosApi(clima.data)

        const historical_data = await supabase.rpc('historical_data', {
          id_cidade: closest_city.id
        })

        console.log('HISTORICAL', historical_data.data)
        sethistoricalData(historical_data.data)

      } else {
        const getIPData = async () => {
          fetch('https://ipinfo.io/json')
            .then((res) => res.json())
            .then((data) => {
              console.log(data);
              localStorage.setItem("IP_DATA", JSON.stringify(data));
              setData(data)
              setLoading(false)
            })
        }
        let ipData = localStorage.getItem("IP_DATA") as any;

        if (ipData) {
          setData(JSON.parse(ipData))
          setLoading(false)
        } else {
          await getIPData();
          ipData = localStorage.getItem("IP_DATA");
        }

        const { loc } = JSON.parse(ipData);
        console.log("IPDATA", ipData, "LOC", loc);
        const [long, lat] = loc.split(',');
        console.log(long, lat);
        const city_data = await supabase.rpc('nearby_city', {
          lat: parseFloat(lat),
          long: parseFloat(long)
        })

        if (city_data.error) {
          console.log('ERROR', city_data.error);
          return;
        }
        const closest_city = city_data.data[0];
        console.log('CITY DATA', city_data);


        const clima = await supabase
          .from('clima')
          .select('*')
          .eq('cidade', closest_city.id)
          .order('created_at', { ascending: false })
          .limit(10);

        if (clima.error) {
          console.error('Error fetching data:', clima.error);
        } else {
          console.log('Last 10 records for specific id:', clima.data);
        }
        setdadosApi(clima.data)

        const historical_data = await supabase.rpc('historical_data', {
          id_cidade: closest_city.id
        })

        console.log('HISTORICAL', historical_data.data)
        sethistoricalData(historical_data.data)

      }
    }

    main();

  }, [])
  return (
    <>
      <Box>
        <Flex
          bg={useColorModeValue("white", "gray.800")}
          color={useColorModeValue("gray.600", "white")}
          minH={"60px"}
          py={{ base: 2 }}
          px={{ base: 4 }}
          borderBottom={1}
          borderStyle={"solid"}
          borderColor={useColorModeValue("gray.200", "gray.900")}
          align={"center"}
        >
          <Flex
            flex={{ base: 1, md: "auto" }}
            ml={{ base: -2 }}
            display={{ base: "flex", md: "none" }}
          >
            <IconButton
              onClick={onToggle}
              icon={
                isOpen ? (
                  <CloseIcon w={3} h={3} />
                ) : (
                  <HamburgerIcon w={5} h={5} />
                )
              }
              variant={"ghost"}
              aria-label={"Toggle Navigation"}
            />
          </Flex>
          <Flex flex={{ base: 1 }} justify={{ base: "center", md: "start" }}>

            <Image src="/logov2.png" objectFit='contain' alt="Logo VaiChuve"></Image>

            <Flex display={{ base: "none", md: "flex" }} ml={10}>
              <DesktopNav />
            </Flex>
          </Flex>

          <Stack
            flex={{ base: 1, md: 0 }}
            justify={"flex-end"}
            direction={"row"}
            spacing={6}
          >
            <Link href='/estados'><Button variant={"outline"}>Alterar Localização</Button></Link>
            {/* <Button  variant={"outline"}>Sair</Button> */}
          </Stack>
        </Flex>

        <Collapse in={isOpen} animateOpacity>
          <MobileNav />
        </Collapse>
      </Box>
      <Box m={5} borderRadius={10}>
        <Tabs variant="solid-rounded" colorScheme="gray" isFitted>
          <TabList
            bgColor={useColorModeValue("gray.300", "gray.800")}
            borderRadius={50}
          >
            <Tab>PREVISÃO DO TEMPO HOJE</Tab>
            <Tab>PREVISÃO DO TEMPO PRÓXIMOS 15 DIAS</Tab>
            <Tab>HISTÓRICO PREVISÃO DO TEMPO</Tab>
          </TabList>
          <TabPanels>
            <TabPanel mx={0} px={0}>
              <Box>
                <Card bgColor={useColorModeValue("gray.100", "gray.900")}>
                  <CardBody>
                    <Box mb={2}>
                      <Heading as='h2' size='lg'>Previsão do tempo para {data?.city ?? '...'}, {data?.region ?? '...'}</Heading>
                    </Box>
                    <Box w={"100%"} h={"150px"} p={0}>
                      <Image
                        boxSize="100%"
                        objectFit="cover"
                        src="/ensolarado.jpg"
                        alt=""
                      />
                    </Box>
                    <Grid templateColumns='repeat(4, 1fr)' gap={6} fontSize={'lg'} fontWeight={'500'} my={4}>
                      <GridItem><Text>Temperatura Mínima: {dadosApi?.[0]?.dados_api?.daily?.[0]?.temp?.min ?? '??'} ºC</Text></GridItem>
                      <GridItem><Text>Temperatura Máxima: {dadosApi?.[0]?.dados_api?.daily?.[0]?.temp?.max ?? '??'} ºC</Text></GridItem>
                      <GridItem><Text>Provabilidade de Precipitação: {dadosApi?.[0]?.dados_api?.daily?.[0]?.pop ?? '??'} %</Text></GridItem>
                      <GridItem><Text>Vento: {dadosApi?.[0]?.dados_api?.daily?.[0]?.wind_speed ?? '??'} km/h</Text></GridItem>
                    </Grid>
                    <Box bgColor={"white"} borderRadius={"20"}>
                      <TableContainer>
                        <Table variant="simple">
                          <TableCaption>
                            Previsão do tempo para próximas horas
                          </TableCaption>
                          <Thead>
                            <Tr>
                              <Th>Horário</Th>
                              <Th>Previsão</Th>
                            </Tr>
                          </Thead>
                          <Tbody>
                            {(dadosApi?.[0]?.dados_api?.hourly ?? []).map((item: any, index: any) => {
                              if (index < 24)
                                return (
                                  <Tr key={index+'-horas'}>
                                    <Td>{new Date(item.dt * 1000).toLocaleTimeString('pt-BR')}</Td>
                                    <Td>{item.weather[0].description.charAt(0).toUpperCase() + item.weather[0].description.slice(1) + ', com temperatura de ' + item.temp + 'ºC, com provabilidade de precipitação de ' + item.pop + '%'}</Td>
                                  </Tr>
                                )
                            })}
                          </Tbody>
                        </Table>
                      </TableContainer>
                    </Box>
                  </CardBody>
                </Card>
              </Box>
            </TabPanel>
            <TabPanel>
              <Box>
                <Card bgColor={useColorModeValue("gray.100", "gray.900")}>
                  <CardBody>
                    <Box mb={2}>
                      <Heading as='h2' size='lg'>Previsão do tempo para {data?.city ?? '...'}, {data?.region ?? '...'}, nos próximos 15 Dias</Heading>
                    </Box>
                    <Grid templateColumns='repeat(4, 1fr)' gap={6} fontSize={'lg'} fontWeight={'100'} my={4}>
                      {(dadosApi?.[0]?.dados_api?.daily ?? []).map((item: any, index: any) => {
                        if (index < 14)
                          return (
                            <GridItem key={index+'-15-dias'}>
                              <Box>
                                <Heading as='h3' size='md'>{
                                  new Date(item.dt * 1000).toLocaleDateString('pt-BR', { year: 'numeric', month: 'long', day: 'numeric' })
                                }</Heading>
                                <Text>Temperatura Mínima: {item?.temp?.min} ºC</Text>
                                <Text>Temperatura Máxima: {item?.temp?.max} ºC</Text>
                                <Text>Precipitação: {item?.pop} %</Text>
                                <Text>Vento: {item?.wind_speed} km/h</Text>
                              </Box>
                            </GridItem>
                          )
                      })}

                    </Grid>
                  </CardBody>
                </Card>
              </Box>
            </TabPanel>
            <TabPanel>
              <Box>
                <Card bgColor={useColorModeValue("gray.100", "gray.900")}>
                  <CardBody>
                    <Box mb={2}>
                      <Heading as='h2' size='lg'>Histórico de Previsão do tempo para {data?.city ?? '...'}, {data?.region ?? '...'}</Heading>
                    </Box>
                    <Grid
                      templateColumns="repeat(4, 1fr)"
                      gap={6}
                      fontSize={"lg"}
                      fontWeight={"100"}
                      my={4}
                    >
                      {(historicalData ?? []).map((item: any, index: any) => {
                        if (index < 14)
                          return (
                            <GridItem key={index+'-hist'}>
                              <Box>
                                <Heading as='h3' size='md'>{
                                  new Date(item.dados_api.current.dt * 1000).toLocaleDateString('pt-BR', { year: 'numeric', month: 'long', day: 'numeric' })
                                }</Heading>
                                <Text>Temperatura: {item?.dados_api?.current.temp} ºC</Text>
                                <Text>Precipitação: {item?.dados_api?.daily?.[0]?.pop} %</Text>
                                <Text>Vento: {item?.dados_api?.current?.wind_speed} km/h</Text>
                              </Box>
                            </GridItem>
                          )
                      })}
                    </Grid>
                  </CardBody>
                </Card>
              </Box>
            </TabPanel>
          </TabPanels>
        </Tabs>
      </Box>
    </>
  );
}

const DesktopNav = () => {
  const linkColor = useColorModeValue("gray.600", "gray.200");
  const linkHoverColor = useColorModeValue("gray.800", "white");
  const popoverContentBgColor = useColorModeValue("white", "gray.800");

  return (
    <Stack direction={"row"} spacing={4}>
      {NAV_ITEMS.map((navItem) => (
        <Box key={navItem.label}>
          <Popover trigger={"hover"} placement={"bottom-start"}>
            <PopoverTrigger>
              <Link
                p={2}
                href={navItem.href ?? "#"}
                fontSize={"md"}
                fontWeight={500}
                color={linkColor}
                _hover={{
                  textDecoration: "none",
                  color: linkHoverColor,
                }}
              >
                {navItem.label}
              </Link>
            </PopoverTrigger>

            {navItem.children && (
              <PopoverContent
                border={0}
                boxShadow={"xl"}
                bg={popoverContentBgColor}
                p={4}
                rounded={"xl"}
                minW={"sm"}
              >
                <Stack>
                  {navItem.children.map((child) => (
                    <DesktopSubNav key={child.label} {...child} />
                  ))}
                </Stack>
              </PopoverContent>
            )}
          </Popover>
        </Box>
      ))}
    </Stack>
  );
};

const DesktopSubNav = ({ label, href, subLabel }: NavItem) => {
  return (
    <Link
      href={href}
      role={"group"}
      display={"block"}
      p={2}
      rounded={"md"}
      _hover={{ bg: useColorModeValue("pink.50", "gray.900") }}
    >
      <Stack direction={"row"} align={"center"}>
        <Box>
          <Text
            transition={"all .3s ease"}
            _groupHover={{ color: "pink.400" }}
            fontWeight={500}
          >
            {label}
          </Text>
          <Text fontSize={"sm"}>{subLabel}</Text>
        </Box>
        <Flex
          transition={"all .3s ease"}
          transform={"translateX(-10px)"}
          opacity={0}
          _groupHover={{ opacity: "100%", transform: "translateX(0)" }}
          justify={"flex-end"}
          align={"center"}
          flex={1}
        >
          <Icon color={"pink.400"} w={5} h={5} as={ChevronRightIcon} />
        </Flex>
      </Stack>
    </Link>
  );
};

const MobileNav = () => {
  return (
    <Stack
      bg={useColorModeValue("white", "gray.800")}
      p={4}
      display={{ md: "none" }}
    >
      {NAV_ITEMS.map((navItem) => (
        <MobileNavItem key={navItem.label} {...navItem} />
      ))}
    </Stack>
  );
};

const MobileNavItem = ({ label, children, href }: NavItem) => {
  const { isOpen, onToggle } = useDisclosure();

  return (
    <Stack spacing={4} onClick={children && onToggle}>
      <Flex
        py={2}
        as={Link}
        href={href ?? "#"}
        justify={"space-between"}
        align={"center"}
        _hover={{
          textDecoration: "none",
        }}
      >
        <Text
          fontWeight={600}
          color={useColorModeValue("gray.600", "gray.200")}
        >
          {label}
        </Text>
        {children && (
          <Icon
            as={ChevronDownIcon}
            transition={"all .25s ease-in-out"}
            transform={isOpen ? "rotate(180deg)" : ""}
            w={6}
            h={6}
          />
        )}
      </Flex>

      <Collapse in={isOpen} animateOpacity style={{ marginTop: "0!important" }}>
        <Stack
          mt={2}
          pl={4}
          borderLeft={1}
          borderStyle={"solid"}
          borderColor={useColorModeValue("gray.200", "gray.700")}
          align={"start"}
        >
          {children &&
            children.map((child) => (
              <Link key={child.label} py={2} href={child.href}>
                {child.label}
              </Link>
            ))}
        </Stack>
      </Collapse>
    </Stack>
  );
};

interface NavItem {
  label: string;
  subLabel?: string;
  children?: Array<NavItem>;
  href?: string;
}

const NAV_ITEMS: Array<NavItem> = [
  {
    label: "Página Inicial",
    href: "/",
  },
  {
    label: "Notícias",
    href: "/noticias",
  },
  {
    label: "Ajustes de Acessibilidade",
    href: "/acessibilidade",
  },
];
